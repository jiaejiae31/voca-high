/**
 * ==============================================================================
 * 보카하이 (vocahigh) - 단어 데이터셋 및 망각곡선 로직 매니저 (data.js)
 * ==============================================================================
 * 
 * [역할 및 설명]
 * 1. 고품질 기본 영단어 데이터셋(그림, 발음기호, 예문, 유의어, 반의어 포함) 제공
 * 2. 에빙하우스 망각곡선 주기(1일, 3일, 7일, 14일, 30일) 기반 복습 스케줄 계산
 * 3. 2일(48시간) 이상 미복습 시 '누적(Overdue)' 상태 감지 및 플래그 관리
 * 4. 복습 비율(100%, 70%, 50%, 30%) 랜덤 추출 함수
 * 5. 브라우저 로컬스토리지(LocalStorage) 데이터 영속성 관리
 * 6. 웹 음성 합성 API(SpeechSynthesis)를 활용한 원어민 발음 듣기 기능
 */

// 로컬스토리지 저장소 키 이름
const STORAGE_KEY = 'VOCAHIGH_WORDS_DATA_V1';

// 망각곡선 복습 주기 (일 단위: 1차=1일, 2차=3일, 3차=7일, 4차=14일, 5차=30일)
export const REVIEW_INTERVALS = [1, 3, 7, 14, 30];

// 2일 미복습 시 누적 판정 기준 밀리초 (2일 = 48시간)
export const OVERDUE_THRESHOLD_MS = 2 * 24 * 60 * 60 * 1000;

/**
 * 기본 영단어 데이터베이스 (24개 핵심 어휘)
 * - 그림(Unsplash 고화질 직관적 이미지)
 * - 예문 및 우리말 해석
 * - 유의어(Synonyms) 및 반의어(Antonyms)
 */
export const INITIAL_WORDS = [
  {
    id: "word-1",
    word: "persistent",
    meaning: "끈기 있는, 집요한, 지속적인",
    phonetic: "/pərˈsɪs.tənt/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "Her persistent efforts eventually led to a breakthrough in the research.",
    exampleTranslation: "그녀의 끈기 있는 노력은 결국 연구에서 획기적인 발전으로 이어졌다.",
    synonyms: ["tenacious", "determined", "enduring"],
    antonyms: ["irresolute", "fleeting", "surrendering"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-2",
    word: "cherish",
    meaning: "소중히 여기다, 아끼다, 간직하다",
    phonetic: "/ˈtʃer.ɪʃ/",
    partOfSpeech: "동사",
    imageUrl: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "I will always cherish the precious memories we shared this summer.",
    exampleTranslation: "나는 올여름 우리가 함께 나눈 소중한 추억들을 언제나 아낄 것이다.",
    synonyms: ["treasure", "value", "appreciate"],
    antonyms: ["neglect", "disregard", "abandon"],
    level: "초급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-3",
    word: "resilient",
    meaning: "회복력 있는, 탄력 있는, 곧 기운을 차리는",
    phonetic: "/rɪˈzɪl.jənt/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "Children are often surprisingly resilient when facing unexpected challenges.",
    exampleTranslation: "아이들은 예상치 못한 난관에 부딪혔을 때 놀라울 정도로 회복력이 있는 경우가 많다.",
    synonyms: ["flexible", "adaptable", "tough"],
    antonyms: ["fragile", "vulnerable", "weak"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-4",
    word: "contemplate",
    meaning: "심사숙고하다, 깊이 생각하다, 응시하다",
    phonetic: "/ˈkɑːn.təm.pleɪt/",
    partOfSpeech: "동사",
    imageUrl: "https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "He sat quietly by the lake to contemplate his future career path.",
    exampleTranslation: "그는 미래의 진로를 깊이 생각하기 위해 호숫가에 조용히 앉아 있었다.",
    synonyms: ["ponder", "meditate", "reflect on"],
    antonyms: ["ignore", "overlook", "disregard"],
    level: "고급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-5",
    word: "thrive",
    meaning: "번영하다, 잘 자라다, 성공하다",
    phonetic: "/θraɪv/",
    partOfSpeech: "동사",
    imageUrl: "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "These delicate flowers thrive when placed in abundant morning sunlight.",
    exampleTranslation: "이 연약한 꽃들은 아침의 풍부한 햇살 속에 놓일 때 아주 잘 자란다.",
    synonyms: ["flourish", "prosper", "bloom"],
    antonyms: ["wither", "deteriorate", "fail"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-6",
    word: "reluctant",
    meaning: "꺼리는, 마지못해 하는, 주저하는",
    phonetic: "/rɪˈlʌk.tənt/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1541199249251-f713e6145474?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "He was reluctant to admit his mistake in front of all his colleagues.",
    exampleTranslation: "그는 모든 동료들 앞에서 자신의 실수를 인정하기를 꺼려했다.",
    synonyms: ["hesitant", "unwilling", "loath"],
    antonyms: ["eager", "willing", "enthusiastic"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-7",
    word: "profound",
    meaning: "깊은, 심오한, 엄청난",
    phonetic: "/prəˈfaʊnd/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "His insightful speech had a profound impact on the young audience.",
    exampleTranslation: "그의 통찰력 있는 연설은 젊은 청중들에게 깊은 영향을 미쳤다.",
    synonyms: ["deep", "insightful", "intense"],
    antonyms: ["superficial", "shallow", "trivial"],
    level: "고급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-8",
    word: "luminous",
    meaning: "빛을 발하는, 어둠 속에서 빛나는, 총명한",
    phonetic: "/ˈluː.mə.nəs/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "The full moon cast a luminous glow across the quiet ocean waves.",
    exampleTranslation: "보름달이 고요한 바다 물결 위에 눈부시게 빛나는 빛을 드리웠다.",
    synonyms: ["radiant", "glowing", "shining"],
    antonyms: ["dim", "dark", "gloomy"],
    level: "고급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-9",
    word: "elaborate",
    meaning: "정교한, 공들인 / 상세히 설명하다",
    phonetic: "/iˈlæb.ɚ.ət/",
    partOfSpeech: "형용사/동사",
    imageUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "The artisan spent months creating this elaborate wooden clockwork.",
    exampleTranslation: "장인은 이 정교한 목제 시계 장치를 만드는 데 몇 달을 보냈다.",
    synonyms: ["intricate", "detailed", "complex"],
    antonyms: ["simple", "crude", "plain"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-10",
    word: "genuine",
    meaning: "진짜의, 진품의, 진실한, 순수한",
    phonetic: "/ˈdʒen.ju.ɪn/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "She showed genuine concern and kindness for everyone who visited.",
    exampleTranslation: "그녀는 방문한 모든 사람들에게 진실한 관심과 친절을 보여주었다.",
    synonyms: ["authentic", "sincere", "real"],
    antonyms: ["fake", "counterfeit", "hypocritical"],
    level: "초급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-11",
    word: "ambiguous",
    meaning: "모호한, 두 가지 이상의 뜻으로 해석되는",
    phonetic: "/æmˈbɪɡ.ju.əs/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "The wording in the contract was ambiguous and led to confusion.",
    exampleTranslation: "계약서의 문구가 모호하여 혼란을 초래했다.",
    synonyms: ["vague", "unclear", "equivocal"],
    antonyms: ["clear", "lucid", "precise"],
    level: "고급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-12",
    word: "empathy",
    meaning: "공감, 감정 이입",
    phonetic: "/ˈem.pə.θi/",
    partOfSpeech: "명사",
    imageUrl: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "Developing empathy helps us build deeper and healthier relationships.",
    exampleTranslation: "공감 능력을 기르는 것은 더 깊고 건강한 인간관계를 구축하는 데 도움이 된다.",
    synonyms: ["compassion", "understanding", "affinity"],
    antonyms: ["apathy", "indifference", "callousness"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-13",
    word: "meticulous",
    meaning: "꼼꼼한, 세심한, 빈틈없는",
    phonetic: "/məˈtɪk.jə.ləs/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "The scientist conducted meticulous observations under the microscope.",
    exampleTranslation: "그 과학자는 현미경 아래에서 세심하고 꼼꼼한 관찰을 진행했다.",
    synonyms: ["thorough", "painstaking", "scrupulous"],
    antonyms: ["careless", "sloppy", "negligent"],
    level: "고급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-14",
    word: "inspire",
    meaning: "영감을 주다, 고무하다, 북돋우다",
    phonetic: "/ɪnˈspaɪər/",
    partOfSpeech: "동사",
    imageUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "Great teachers inspire students to explore knowledge beyond textbooks.",
    exampleTranslation: "훌륭한 교사들은 학생들이 교과서를 넘어 지식을 탐구하도록 고무한다.",
    synonyms: ["motivate", "encourage", "stimulate"],
    antonyms: ["discourage", "dissuade", "demoralize"],
    level: "초급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-15",
    word: "versatile",
    meaning: "다재다능한, 다용도의, 변하기 쉬운",
    phonetic: "/ˈvɝː.sə.t̬əl/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "This smartphone app is versatile enough to manage both work and daily life.",
    exampleTranslation: "이 스마트폰 앱은 업무와 일상생활 모두를 관리할 수 있을 만큼 다용도이다.",
    synonyms: ["adaptable", "multipurpose", "flexible"],
    antonyms: ["inflexible", "limited", "narrow"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  },
  {
    id: "word-16",
    word: "abundant",
    meaning: "풍부한, 아주 많은, 넘쳐나는",
    phonetic: "/əˈbʌn.dənt/",
    partOfSpeech: "형용사",
    imageUrl: "https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=600&auto=format&fit=crop&q=80",
    exampleSentence: "The valley is blessed with abundant harvest and fresh water springs.",
    exampleTranslation: "그 계곡은 풍부한 수확과 신선한 샘물의 축복을 받았다.",
    synonyms: ["plentiful", "copious", "bountiful"],
    antonyms: ["scarce", "meager", "deficient"],
    level: "중급",
    repetitionStage: 0,
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    isOverdue: false,
    correctCount: 0,
    incorrectCount: 0
  }
];

/**
 * 특정 단어가 2일(48시간) 이상 미복습되어 누적(Overdue) 상태인지 점검
 * @param {Object} word - 단어 객체
 * @returns {boolean} 누적 여부
 */
export function calculateIsOverdue(word) {
  if (!word || !word.nextReviewAt) return false;
  const nextReviewTime = new Date(word.nextReviewAt).getTime();
  const now = Date.now();
  // 예정된 복습 시간보다 48시간 이상 지났다면 누적으로 판정
  return now - nextReviewTime >= OVERDUE_THRESHOLD_MS;
}

/**
 * 단어 목록 전체에 대해 현재 시점 기준 누적(isOverdue) 상태를 갱신
 * @param {Array} words - 단어 배열
 * @returns {Array} 갱신된 단어 배열
 */
export function refreshWordsOverdueStatus(words) {
  return words.map(word => ({
    ...word,
    isOverdue: calculateIsOverdue(word)
  }));
}

/**
 * 로컬스토리지에서 단어 데이터 불러오기 (없으면 초기 데이터셋 적재)
 * @returns {Array} 단어 배열
 */
export function loadWords() {
  try {
    const rawData = localStorage.getItem(STORAGE_KEY);
    if (!rawData) {
      // 처음 접속 시 기본 데이터셋으로 초기화 및 저장
      saveWords(INITIAL_WORDS);
      return refreshWordsOverdueStatus(INITIAL_WORDS);
    }
    const parsed = JSON.parse(rawData);
    return refreshWordsOverdueStatus(parsed);
  } catch (error) {
    console.error("단어 데이터를 불러오는 중 오류 발생:", error);
    return refreshWordsOverdueStatus(INITIAL_WORDS);
  }
}

/**
 * 로컬스토리지에 단어 데이터 저장
 * @param {Array} words - 저장할 단어 배열
 */
export function saveWords(words) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(words));
  } catch (error) {
    console.error("단어 데이터를 로컬스토리지에 저장하는 중 오류 발생:", error);
  }
}

/**
 * 망각곡선 복습 결과에 따라 단어의 주기 및 통계 업데이트
 * 
 * [에빙하우스 주기 룰]
 * - 정답인 경우: 복습 차수(repetitionStage) + 1 (최대 5단계)
 *   다음 복습일: 현재 시점 + REVIEW_INTERVALS[새 차수-1]일
 * - 오답인 경우: 복습 차수를 1단계로 리셋하여 1일 뒤 재복습 유도
 * 
 * @param {Object} word - 업데이트할 단어 객체
 * @param {boolean} isSuccess - 정답 여부 (true: 정답/완료, false: 오답/틀림)
 * @returns {Object} 갱신된 단어 객체
 */
export function updateWordAfterReview(word, isSuccess) {
  const now = new Date();
  let newStage = word.repetitionStage;

  if (isSuccess) {
    // 성공 시 차수 증가 (최대 5차: 30일 주기)
    newStage = Math.min(newStage + 1, REVIEW_INTERVALS.length);
  } else {
    // 실패 시 1단계로 재설정 (내일 다시 복습)
    newStage = 1;
  }

  // 다음 복습 일시 계산
  const intervalDays = REVIEW_INTERVALS[Math.max(0, newStage - 1)];
  const nextDate = new Date(now.getTime() + intervalDays * 24 * 60 * 60 * 1000);

  return {
    ...word,
    repetitionStage: newStage,
    lastReviewedAt: now.toISOString(),
    nextReviewAt: nextDate.toISOString(),
    isOverdue: false, // 복습을 마쳤으므로 누적 해제
    correctCount: word.correctCount + (isSuccess ? 1 : 0),
    incorrectCount: word.incorrectCount + (isSuccess ? 0 : 1)
  };
}

/**
 * 복습 대기 중인 단어만 필터링 (복습 예정 시각이 현재 시각 이전이거나 누적된 단어)
 * @param {Array} words - 전체 단어 목록
 * @returns {Array} 복습 대상 단어들
 */
export function getDueWords(words) {
  const now = Date.now();
  return words.filter(word => {
    if (!word.nextReviewAt) return true;
    return new Date(word.nextReviewAt).getTime() <= now || word.isOverdue;
  });
}

/**
 * 2일 이상 미복습으로 밀려 누적된 단어들만 필터링
 * @param {Array} words - 전체 단어 목록
 * @returns {Array} 누적 단어들
 */
export function getOverdueWords(words) {
  return words.filter(word => word.isOverdue);
}

/**
 * 단어 목록에서 지정한 비율(100%, 70%, 50%, 30%)만큼 랜덤으로 추출
 * 
 * @param {Array} words - 대상 단어 배열
 * @param {number} ratio - 비율 (1.0 = 전체, 0.7 = 70%, 0.5 = 50%, 0.3 = 30%)
 * @returns {Array} 무작위 추출된 단어 배열
 */
export function sampleWordsByRatio(words, ratio = 1.0) {
  if (!words || words.length === 0) return [];
  
  // 1. 원본 배열을 손상시키지 않고 복사 후 무작위 셔플 (Fisher-Yates 알고리즘)
  const shuffled = [...words];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  // 2. 비율에 해당하는 단어 개수 계산 (최소 1개 이상 보장)
  if (ratio >= 1.0) return shuffled;
  const count = Math.max(1, Math.round(words.length * ratio));
  
  // 3. 앞에서부터 계산된 개수만큼 잘라서 반환
  return shuffled.slice(0, count);
}

/**
 * 브라우저 내장 Web Speech API를 활용하여 영어 단어를 원어민 발음으로 재생
 * @param {string} text - 발음할 영단어
 */
export function speakWord(text) {
  if (!window.speechSynthesis) {
    console.warn("이 브라우저는 Web Speech API를 지원하지 않습니다.");
    return;
  }
  // 재생 중인 음성이 있다면 중단
  window.speechSynthesis.cancel();
  
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-US'; // 미국 영어 발음
  utterance.rate = 0.9;     // 조금 또렷하게 듣기 위해 0.9배속
  utterance.pitch = 1.0;
  
  window.speechSynthesis.speak(utterance);
}
