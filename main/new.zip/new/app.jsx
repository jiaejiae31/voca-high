/**
 * ==============================================================================
 * 보카하이 (vocahigh) - 메인 애플리케이션 컴포넌트 (app.jsx)
 * ==============================================================================
 * 
 * [주요 기능 및 구조]
 * 1. 망각곡선 주기 자동 복습 위젯:
 *    - 오늘 복습할 단어 수 및 2일 이상 미복습 누적(Overdue) 단어 경고 표시
 *    - 복습 분량 선택 (100% 전체, 70%, 50%, 30% 랜덤 단어 추출)
 *    - 3가지 훈련(플래시카드, 4지선다, 스펠링) 중 하나를 선택해 복습 진행
 * 
 * 2. <학습> 모드:
 *    - 일반 단어장: 고화질 이미지, 발음기호, 뜻, 예문/해석, 유의어/반의어 카드 뷰
 *    - 단어 리스트: 깔끔하고 정돈된 단어/뜻 테이블 뷰 (검색 및 정렬 지원)
 * 
 * 3. <훈련> 모드 (총 24개 세부 버전):
 *    - 훈련 종류(3종): ① 플래시 카드  ② 4지선다 퀴즈  ③ 스펠링 타이핑 훈련
 *    - 언어 방향(2종): ① 영 ➔ 한     ② 한 ➔ 영
 *    - 보기 방식(2종): ① 하나씩 보기  ② 나열로 보기
 *    - 카운트다운(2종): ① 타이머 켜기 ② 타이머 끄기
 *    => 3 x 2 x 2 x 2 = 총 24가지 훈련 모드 지원!
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  INITIAL_WORDS,
  loadWords,
  saveWords,
  updateWordAfterReview,
  sampleWordsByRatio,
  speakWord,
  getDueWords,
  getOverdueWords,
  REVIEW_INTERVALS
} from './data.js';

export default function App() {
  // --------------------------------------------------------------------------
  // [1. 상태 관리 (State Management)]
  // --------------------------------------------------------------------------
  
  // 전체 단어 목록 (로컬스토리지에서 로드)
  const [words, setWords] = useState(() => loadWords());
  
  // 현재 메인 탭: 'study' (학습) | 'training' (훈련) | 'reviewModal'
  const [mainTab, setMainTab] = useState('study');

  // <학습> 서브 모드: 'card' (일반 단어장) | 'table' (단어 리스트 표)
  const [studySubTab, setStudySubTab] = useState('card');
  const [currentStudyIndex, setCurrentStudyIndex] = useState(0);
  const [isMeaningVisible, setIsMeaningVisible] = useState(true); // 카드에서 뜻 가리기/보이기 토글
  const [searchQuery, setSearchQuery] = useState(''); // 단어 리스트 검색창

  // <훈련> 24개 조합을 결정하는 4가지 핵심 옵션
  const [trainingType, setTrainingType] = useState('flashcard'); // 'flashcard' | 'quiz' | 'spelling' (3종)
  const [direction, setDirection] = useState('en-to-ko');        // 'en-to-ko' | 'ko-to-en' (2종)
  const [viewType, setViewType] = useState('single');           // 'single' (하나씩) | 'list' (나열로) (2종)
  const [useCountdown, setUseCountdown] = useState(false);      // true | false (2종)
  
  // 훈련 세션 상태
  const [activeSessionWords, setActiveSessionWords] = useState([]); // 현재 훈련에 사용 중인 단어 목록
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0); // 현재 문제 번호 (하나씩 보기 모드)
  const [isFlipped, setIsFlipped] = useState(false); // 플래시카드 뒤집힘 상태
  const [spellingInput, setSpellingInput] = useState(''); // 스펠링 훈련 사용자 입력값
  const [spellingFeedback, setSpellingFeedback] = useState(null); // 'correct' | 'wrong' | null
  const [quizSelectedOption, setQuizSelectedOption] = useState(null); // 4지선다 선택한 보기
  const [quizFeedback, setQuizFeedback] = useState(null); // 'correct' | 'wrong' | null
  const [sessionResults, setSessionResults] = useState([]); // 훈련 완료 후 결과 수집
  const [isSessionFinished, setIsSessionFinished] = useState(false); // 훈련 종료 여부

  // 나열형 뷰(List View)용 답변 저장소
  const [listAnswers, setListAnswers] = useState({}); // { [wordId]: answerString }
  const [listFeedbacks, setListFeedbacks] = useState({}); // { [wordId]: 'correct' | 'wrong' }

  // 카운트다운 타이머
  const [timeLeft, setTimeLeft] = useState(10);
  const timerRef = useRef(null);

  // 망각곡선 복습 모달 상태
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewRatio, setReviewRatio] = useState(1.0); // 1.0 (전체), 0.7 (70%), 0.5 (50%), 0.3 (30%)
  const [isReviewSession, setIsReviewSession] = useState(false); // 현재 훈련이 망각곡선 공식 복습인지 여부

  // 단어 추가 모달 상태
  const [showAddWordModal, setShowAddWordModal] = useState(false);
  const [newWordData, setNewWordData] = useState({
    word: '',
    meaning: '',
    phonetic: '',
    partOfSpeech: '명사',
    imageUrl: '',
    exampleSentence: '',
    exampleTranslation: '',
    synonyms: '',
    antonyms: ''
  });

  // --------------------------------------------------------------------------
  // [2. 데이터 영속성 동기화 및 복습 통계 산출]
  // --------------------------------------------------------------------------
  
  // 단어 목록이 갱신될 때마다 로컬스토리지에 자동 저장
  useEffect(() => {
    saveWords(words);
  }, [words]);

  // 오늘 복습해야 하는 단어들
  const dueWords = useMemo(() => getDueWords(words), [words]);

  // 2일 이상 미복습되어 누적(Overdue)된 위험 단어들
  const overdueWords = useMemo(() => getOverdueWords(words), [words]);

  // 학습 탭 단어 검색 필터링
  const filteredWords = useMemo(() => {
    if (!searchQuery.trim()) return words;
    const q = searchQuery.toLowerCase();
    return words.filter(w => 
      w.word.toLowerCase().includes(q) || 
      w.meaning.toLowerCase().includes(q) ||
      (w.exampleSentence && w.exampleSentence.toLowerCase().includes(q))
    );
  }, [words, searchQuery]);

  // --------------------------------------------------------------------------
  // [3. 훈련 세션 시작 및 제어 로직]
  // --------------------------------------------------------------------------

  /**
   * 훈련 세션 시작 함수
   * @param {Array} targetWords - 훈련 대상 단어 목록
   * @param {boolean} isReview - 망각곡선 정기 복습 세션 여부
   */
  const startTrainingSession = (targetWords, isReview = false) => {
    if (!targetWords || targetWords.length === 0) {
      alert("훈련할 대상 단어가 없습니다.");
      return;
    }

    setActiveSessionWords(targetWords);
    setCurrentQuestionIndex(0);
    setIsFlipped(false);
    setSpellingInput('');
    setSpellingFeedback(null);
    setQuizSelectedOption(null);
    setQuizFeedback(null);
    setSessionResults([]);
    setIsSessionFinished(false);
    setListAnswers({});
    setListFeedbacks({});
    setIsReviewSession(isReview);
    setMainTab('training');
    setShowReviewModal(false);

    // 카운트다운 초기화
    if (useCountdown) {
      setTimeLeft(10);
    }
  };

  /**
   * 망각곡선 복습 모드 시작 (비율 샘플링 적용)
   * @param {string} selectedMode - 선택한 복습 훈련 방식 ('flashcard' | 'quiz' | 'spelling')
   */
  const handleStartReviewWithRatio = (selectedMode) => {
    // 복습 대상 단어 (오늘 예정 + 누적 단어)가 없으면 전체 단어에서 선택
    const pool = dueWords.length > 0 ? dueWords : words;
    // 사용자가 선택한 퍼센티지(100%, 70%, 50%, 30%)만큼 무작위 추출!
    const sampled = sampleWordsByRatio(pool, reviewRatio);
    
    setTrainingType(selectedMode);
    startTrainingSession(sampled, true);
  };

  // --------------------------------------------------------------------------
  // [4. 카운트다운 타이머 이펙트]
  // --------------------------------------------------------------------------
  useEffect(() => {
    if (mainTab !== 'training' || isSessionFinished || viewType !== 'single' || !useCountdown) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    // 타이머 인터벌 가동 (1초마다 감소)
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // 시간 초과 시 오답 처리하고 다음 단어로 자동 이동
          handleSingleAnswerTimeout();
          return 10;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [mainTab, isSessionFinished, viewType, useCountdown, currentQuestionIndex]);

  // 제한시간 초과 시 처리
  const handleSingleAnswerTimeout = () => {
    const currentWord = activeSessionWords[currentQuestionIndex];
    if (!currentWord) return;

    recordAnswer(currentWord, false, "시간 초과");
    moveToNextSingleQuestion();
  };

  // --------------------------------------------------------------------------
  // [5. 단어별 정답 기록 및 망각곡선 상태 반영]
  // --------------------------------------------------------------------------
  
  /**
   * 답변 결과 기록 및 망각곡선 단계 반영
   * @param {Object} word - 해당 단어 객체
   * @param {boolean} isSuccess - 정답 여부
   * @param {string} userReply - 사용자 입력값
   */
  const recordAnswer = (word, isSuccess, userReply = "") => {
    // 결과 수집
    setSessionResults(prev => [...prev, { word, isSuccess, userReply }]);

    // 망각곡선 주기 갱신
    setWords(prevWords => 
      prevWords.map(w => w.id === word.id ? updateWordAfterReview(w, isSuccess) : w)
    );
  };

  // 하나씩 보기 모드에서 다음 문제로 이동
  const moveToNextSingleQuestion = () => {
    setIsFlipped(false);
    setSpellingInput('');
    setSpellingFeedback(null);
    setQuizSelectedOption(null);
    setQuizFeedback(null);
    setTimeLeft(10);

    if (currentQuestionIndex + 1 < activeSessionWords.length) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // 모든 문제 완료
      setIsSessionFinished(true);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  // --------------------------------------------------------------------------
  // [6. 훈련 서브모드별 인터랙션 핸들러]
  // --------------------------------------------------------------------------

  // A. 플래시카드: 알고 있음 / 모름 버튼 클릭 시
  const handleFlashcardResult = (isSuccess) => {
    const currentWord = activeSessionWords[currentQuestionIndex];
    recordAnswer(currentWord, isSuccess, isSuccess ? "알고 있음" : "모름");
    moveToNextSingleQuestion();
  };

  // B. 4지선다: 보기 생성 로직 (현재 문제 1개 정답 + 다른 단어 3개 오답 무작위 추출)
  const currentQuizOptions = useMemo(() => {
    if (activeSessionWords.length === 0) return [];
    const currentWord = activeSessionWords[currentQuestionIndex];
    if (!currentWord) return [];

    // 정답 텍스트 (방향에 따라 결정)
    const correctAnswer = direction === 'en-to-ko' ? currentWord.meaning : currentWord.word;

    // 오답 후보들 (다른 단어들에서 추출)
    const otherWords = words.filter(w => w.id !== currentWord.id);
    const shuffledOthers = [...otherWords].sort(() => Math.random() - 0.5);
    const wrongAnswers = shuffledOthers.slice(0, 3).map(w => 
      direction === 'en-to-ko' ? w.meaning : w.word
    );

    // 4개 보기를 섞음
    const allOptions = [correctAnswer, ...wrongAnswers].sort(() => Math.random() - 0.5);
    return allOptions;
  }, [activeSessionWords, currentQuestionIndex, direction, words]);

  // B. 4지선다: 정답 선택 핸들러
  const handleQuizSelect = (selectedOption) => {
    if (quizFeedback !== null) return; // 이미 선택한 경우 중복 방지

    const currentWord = activeSessionWords[currentQuestionIndex];
    const correctAnswer = direction === 'en-to-ko' ? currentWord.meaning : currentWord.word;
    const isCorrect = selectedOption.trim() === correctAnswer.trim();

    setQuizSelectedOption(selectedOption);
    setQuizFeedback(isCorrect ? 'correct' : 'wrong');

    // 정답 기록
    recordAnswer(currentWord, isCorrect, selectedOption);

    // 0.8초 후 피드백 보여주고 다음 문제로 전환
    setTimeout(() => {
      moveToNextSingleQuestion();
    }, 850);
  };

  // C. 스펠링: 키보드 입력 제출 핸들러
  const handleSpellingSubmit = (e) => {
    if (e) e.preventDefault();
    if (!spellingInput.trim() || spellingFeedback !== null) return;

    const currentWord = activeSessionWords[currentQuestionIndex];
    // 영문 스펠링 검사 (소문자 변환 후 공백 제거 비교)
    const targetSpelling = direction === 'ko-to-en' ? currentWord.word : currentWord.meaning;
    
    // 영어 철자일 경우 대소문자 무시하고 매칭
    const isMatch = direction === 'ko-to-en'
      ? spellingInput.trim().toLowerCase() === targetSpelling.trim().toLowerCase()
      : spellingInput.trim() === targetSpelling.trim();

    setSpellingFeedback(isMatch ? 'correct' : 'wrong');
    recordAnswer(currentWord, isMatch, spellingInput);

    // 0.9초 후 피드백 보여주고 다음으로 이동
    setTimeout(() => {
      moveToNextSingleQuestion();
    }, 900);
  };

  // --------------------------------------------------------------------------
  // [7. 나열로 보기 (List View) 일괄 채점 로직]
  // --------------------------------------------------------------------------
  const handleGradeListAnswers = () => {
    const newFeedbacks = {};
    const newResults = [];

    activeSessionWords.forEach(word => {
      const userAns = listAnswers[word.id] || "";
      const targetAns = direction === 'en-to-ko' ? word.meaning : word.word;
      
      let isCorrect = false;
      if (direction === 'ko-to-en') {
        isCorrect = userAns.trim().toLowerCase() === targetAns.trim().toLowerCase();
      } else {
        isCorrect = userAns.trim().includes(targetAns.trim()) || targetAns.trim().includes(userAns.trim());
      }

      newFeedbacks[word.id] = isCorrect ? 'correct' : 'wrong';
      newResults.push({ word, isSuccess: isCorrect, userReply: userAns });

      // 단어 주기 업데이트
      setWords(prev => prev.map(w => w.id === word.id ? updateWordAfterReview(w, isCorrect) : w));
    });

    setListFeedbacks(newFeedbacks);
    setSessionResults(newResults);
    setIsSessionFinished(true);
  };

  // --------------------------------------------------------------------------
  // [8. 새 단어 추가 핸들러]
  // --------------------------------------------------------------------------
  const handleAddWordSubmit = (e) => {
    e.preventDefault();
    if (!newWordData.word.trim() || !newWordData.meaning.trim()) {
      alert("단어와 뜻은 필수 입력 항목입니다.");
      return;
    }

    const createdWord = {
      id: `word-${Date.now()}`,
      word: newWordData.word.trim(),
      meaning: newWordData.meaning.trim(),
      phonetic: newWordData.phonetic.trim() || `/${newWordData.word.trim()}/`,
      partOfSpeech: newWordData.partOfSpeech || '명사',
      imageUrl: newWordData.imageUrl.trim() || 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=600&auto=format&fit=crop&q=80',
      exampleSentence: newWordData.exampleSentence.trim() || `Practice makes perfect with ${newWordData.word.trim()}.`,
      exampleTranslation: newWordData.exampleTranslation.trim() || `연습은 완벽을 만듭니다.`,
      synonyms: newWordData.synonyms ? newWordData.synonyms.split(',').map(s => s.trim()).filter(Boolean) : [],
      antonyms: newWordData.antonyms ? newWordData.antonyms.split(',').map(a => a.trim()).filter(Boolean) : [],
      level: '중급',
      repetitionStage: 0,
      lastReviewedAt: null,
      nextReviewAt: new Date().toISOString(),
      isOverdue: false,
      correctCount: 0,
      incorrectCount: 0
    };

    setWords(prev => [createdWord, ...prev]);
    setShowAddWordModal(false);
    setNewWordData({
      word: '', meaning: '', phonetic: '', partOfSpeech: '명사',
      imageUrl: '', exampleSentence: '', exampleTranslation: '', synonyms: '', antonyms: ''
    });
    alert(`단어 '${createdWord.word}'가 성공적으로 추가되었습니다!`);
  };

  // --------------------------------------------------------------------------
  // [9. 렌더링 화면 구성]
  // --------------------------------------------------------------------------
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* ----------------- 최상단 헤더 네비게이션 ----------------- */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* 서비스 로고 및 타이틀 */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setMainTab('study')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <span className="text-xl font-black text-white tracking-tighter">VH</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400 bg-clip-text text-transparent">
                  보카하이 <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-700/50">vocahigh</span>
                </h1>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">에빙하우스 망각곡선 주기 자동 복습 & 24개 맞춤 훈련 시스템</p>
            </div>
          </div>

          {/* 중앙 네비게이션 탭 */}
          <div className="flex items-center gap-1 bg-slate-800/90 p-1 rounded-xl border border-slate-700/70">
            <button
              id="nav-tab-study"
              onClick={() => { setMainTab('study'); setIsSessionFinished(false); }}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center gap-2 ${
                mainTab === 'study'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <span>📖</span>
              <span>학습 모드</span>
            </button>

            <button
              id="nav-tab-training"
              onClick={() => {
                if (activeSessionWords.length === 0) {
                  startTrainingSession(words);
                }
                setMainTab('training');
              }}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center gap-2 ${
                mainTab === 'training'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <span>⚡</span>
              <span>훈련 모드 (24종)</span>
            </button>
          </div>

          {/* 우측 상단 액션 버튼 (망각곡선 복습 열기 & 단어 추가) */}
          <div className="flex items-center gap-3">
            <button
              id="btn-open-review-modal"
              onClick={() => setShowReviewModal(true)}
              className="relative px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white text-xs sm:text-sm font-bold shadow-lg shadow-orange-500/20 hover:brightness-110 active:scale-95 transition-all flex items-center gap-2"
            >
              <span>🧠</span>
              <span className="hidden sm:inline">망각곡선 복습</span>
              <span className="inline sm:hidden">복습</span>
              {/* 복습할 단어 뱃지 */}
              {dueWords.length > 0 && (
                <span className="ml-1 px-1.5 py-0.2 rounded-full bg-red-600 text-white text-xs font-black animate-pulse">
                  {dueWords.length}
                </span>
              )}
            </button>

            <button
              id="btn-add-word"
              onClick={() => setShowAddWordModal(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <span>➕</span>
              <span className="hidden sm:inline">단어 추가</span>
            </button>
          </div>

        </div>
      </header>

      {/* ----------------- 망각곡선 상태 배너 (상시 알림) ----------------- */}
      <div className="bg-slate-950/70 border-b border-slate-800/80 px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2 text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span>총 단어: <strong className="text-white font-bold">{words.length}개</strong></span>
            </div>
            
            <div className="flex items-center gap-1.5 text-amber-300">
              <span>📅 오늘 권장 복습:</span>
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                {dueWords.length}개 대기 중
              </span>
            </div>

            {/* 2일 이상 미복습 누적 경고 배지 */}
            {overdueWords.length > 0 && (
              <div className="flex items-center gap-1.5 text-rose-300 bg-rose-950/60 px-2.5 py-0.5 rounded-md border border-rose-600/40 animate-pulse">
                <span>⚠️ 2일 이상 미복습 누적:</span>
                <strong className="text-rose-400 font-bold">{overdueWords.length}개</strong>
                <span className="text-xs text-rose-300/80 hidden md:inline">(기억 망각 위험!)</span>
              </div>
            )}
          </div>

          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span>복습 주기: 1일 ➔ 3일 ➔ 7일 ➔ 14일 ➔ 30일 완전 기억</span>
          </div>
        </div>
      </div>

      {/* ----------------- 메인 컨텐츠 영역 ----------------- */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* ================================================================== */}
        {/* 1. <학습 (Study)> 화면 모드                                        */}
        {/* ================================================================== */}
        {mainTab === 'study' && (
          <div className="space-y-6">
            
            {/* 상단 서브 탭 컨트롤러 (일반 단어장 vs 단어 리스트) */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-800/60 p-3 rounded-2xl border border-slate-700/60">
              
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  id="tab-study-card"
                  onClick={() => setStudySubTab('card')}
                  className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                    studySubTab === 'card'
                      ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/25'
                      : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <span>🖼️</span>
                  <span>일반 단어장 (상세 카드)</span>
                </button>

                <button
                  id="tab-study-table"
                  onClick={() => setStudySubTab('table')}
                  className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                    studySubTab === 'table'
                      ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/25'
                      : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <span>📋</span>
                  <span>단어 리스트 (표 형태)</span>
                </button>
              </div>

              {/* 우측 컨트롤 (카드 모드에서는 뜻 가리기 토글, 리스트 모드에서는 검색창) */}
              {studySubTab === 'card' ? (
                <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                  <button
                    onClick={() => setIsMeaningVisible(prev => !prev)}
                    className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-slate-200 border border-slate-600 transition-all flex items-center gap-1.5"
                  >
                    <span>{isMeaningVisible ? '🙈' : '👁️'}</span>
                    <span>{isMeaningVisible ? '뜻 가리기' : '뜻 보기'}</span>
                  </button>

                  <span className="text-xs text-slate-400 font-mono">
                    {words.length > 0 ? `${currentStudyIndex + 1} / ${words.length}` : '0 / 0'}
                  </span>
                </div>
              ) : (
                <div className="w-full sm:w-72">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="단어, 뜻, 예문 검색..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full px-3.5 py-2 pl-9 bg-slate-900/90 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <span className="absolute left-3 top-2.5 text-slate-400 text-sm">🔍</span>
                  </div>
                </div>
              )}
            </div>

            {/* A. 일반 단어장 (그림, 예문, 유의어, 반의어 상세 카드) */}
            {studySubTab === 'card' && words.length > 0 && (
              <div className="max-w-3xl mx-auto">
                {(() => {
                  const word = words[currentStudyIndex];
                  return (
                    <div className="bg-slate-800/80 border border-slate-700/80 rounded-3xl overflow-hidden shadow-2xl backdrop-blur-sm transition-all duration-300">
                      
                      {/* 카드 상단 이미지 배너 */}
                      <div className="relative h-64 sm:h-80 w-full overflow-hidden bg-slate-900">
                        <img
                          src={word.imageUrl}
                          alt={word.word}
                          className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-105"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>

                        {/* 좌측 상단 배지 (품사 및 난이도) */}
                        <div className="absolute top-4 left-4 flex items-center gap-2">
                          <span className="px-3 py-1 rounded-full bg-indigo-600/90 backdrop-blur-md text-xs font-bold text-white shadow-md">
                            {word.partOfSpeech}
                          </span>
                          <span className="px-3 py-1 rounded-full bg-purple-600/90 backdrop-blur-md text-xs font-bold text-white shadow-md">
                            {word.level}
                          </span>
                        </div>

                        {/* 우측 상단 발음 듣기 버튼 */}
                        <button
                          onClick={() => speakWord(word.word)}
                          title="원어민 발음 듣기"
                          className="absolute top-4 right-4 p-3 rounded-full bg-slate-900/80 hover:bg-indigo-600 text-white backdrop-blur-md shadow-lg transition-all active:scale-95 group"
                        >
                          <span className="text-lg group-hover:animate-bounce">🔊</span>
                        </button>

                        {/* 이미지 하단 단어 타이틀 */}
                        <div className="absolute bottom-4 left-6 right-6 flex items-baseline justify-between">
                          <div>
                            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-wide drop-shadow-md">
                              {word.word}
                            </h2>
                            <p className="text-sm font-mono text-indigo-300 mt-1">
                              {word.phonetic}
                            </p>
                          </div>
                          
                          {/* 망각곡선 단계 뱃지 */}
                          <div className="text-right">
                            <span className="inline-block px-2.5 py-1 rounded-lg bg-slate-900/90 text-amber-300 text-xs font-bold border border-amber-500/40">
                              망각곡선 {word.repetitionStage}단계
                            </span>
                            {word.isOverdue && (
                              <p className="text-xs text-rose-400 font-bold mt-1">⚠️ 2일 미복습 누적</p>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* 카드 바디 (뜻, 예문, 유의어, 반의어) */}
                      <div className="p-6 sm:p-8 space-y-6">
                        
                        {/* 1. 우리말 뜻 */}
                        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/50">
                          <span className="text-xs font-bold text-slate-400 tracking-wider uppercase block mb-1">
                            뜻 (Meaning)
                          </span>
                          {isMeaningVisible ? (
                            <p className="text-2xl font-bold text-indigo-200">
                              {word.meaning}
                            </p>
                          ) : (
                            <div 
                              onClick={() => setIsMeaningVisible(true)}
                              className="py-2 text-center text-sm font-semibold text-slate-400 bg-slate-800/80 rounded-xl cursor-pointer hover:bg-slate-700 transition-all border border-dashed border-slate-600"
                            >
                              🔒 뜻이 숨겨져 있습니다. 클릭하여 확인하세요!
                            </div>
                          )}
                        </div>

                        {/* 2. 예문 및 번역 */}
                        <div className="space-y-2">
                          <span className="text-xs font-bold text-slate-400 tracking-wider uppercase block">
                            예문 (Example)
                          </span>
                          <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-900/40 space-y-2">
                            <p className="text-base sm:text-lg font-medium text-slate-100 italic">
                              "{word.exampleSentence}"
                            </p>
                            <p className="text-sm text-slate-400">
                              {word.exampleTranslation}
                            </p>
                          </div>
                        </div>

                        {/* 3. 유의어 & 반의어 태그 */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {/* 유의어 */}
                          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/50">
                            <span className="text-xs font-bold text-emerald-400 tracking-wider uppercase block mb-2">
                              ✨ 유의어 (Synonyms)
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {word.synonyms && word.synonyms.length > 0 ? (
                                word.synonyms.map((syn, idx) => (
                                  <span key={idx} className="px-2.5 py-1 rounded-lg bg-emerald-950/60 text-emerald-300 text-xs font-semibold border border-emerald-700/40">
                                    {syn}
                                  </span>
                                ))
                              ) : (
                                <span className="text-xs text-slate-500">등록된 유의어가 없습니다.</span>
                              )}
                            </div>
                          </div>

                          {/* 반의어 */}
                          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-700/50">
                            <span className="text-xs font-bold text-rose-400 tracking-wider uppercase block mb-2">
                              🔄 반의어 (Antonyms)
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {word.antonyms && word.antonyms.length > 0 ? (
                                word.antonyms.map((ant, idx) => (
                                  <span key={idx} className="px-2.5 py-1 rounded-lg bg-rose-950/60 text-rose-300 text-xs font-semibold border border-rose-700/40">
                                    {ant}
                                  </span>
                                ))
                              ) : (
                                <span className="text-xs text-slate-500">등록된 반의어가 없습니다.</span>
                              )}
                            </div>
                          </div>
                        </div>

                      </div>

                      {/* 카드 하단 이전/다음 네비게이션 */}
                      <div className="px-6 py-4 bg-slate-900/80 border-t border-slate-700/80 flex items-center justify-between">
                        <button
                          onClick={() => setCurrentStudyIndex(prev => Math.max(0, prev - 1))}
                          disabled={currentStudyIndex === 0}
                          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-sm font-semibold transition-all flex items-center gap-2"
                        >
                          <span>⬅️</span>
                          <span>이전 단어</span>
                        </button>

                        <button
                          onClick={() => {
                            // 이 단어로 즉시 훈련 시작
                            startTrainingSession([word]);
                          }}
                          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-sm font-bold text-white shadow-md shadow-indigo-600/30 transition-all flex items-center gap-2"
                        >
                          <span>🎯</span>
                          <span>이 단어 집중 훈련</span>
                        </button>

                        <button
                          onClick={() => setCurrentStudyIndex(prev => Math.min(words.length - 1, prev + 1))}
                          disabled={currentStudyIndex >= words.length - 1}
                          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-sm font-semibold transition-all flex items-center gap-2"
                        >
                          <span>다음 단어</span>
                          <span>➡️</span>
                        </button>
                      </div>

                    </div>
                  );
                })()}
              </div>
            )}

            {/* B. 단어 리스트 (그냥 단어 / 뜻만 나열된 표) */}
            {studySubTab === 'table' && (
              <div className="bg-slate-800/80 rounded-2xl border border-slate-700/70 overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-900/90 border-b border-slate-700 text-xs font-bold text-slate-400 uppercase tracking-wider">
                        <th className="py-3.5 px-4 w-12 text-center">No</th>
                        <th className="py-3.5 px-4">단어 (Word)</th>
                        <th className="py-3.5 px-4">발음</th>
                        <th className="py-3.5 px-4">품사</th>
                        <th className="py-3.5 px-4">뜻 (Meaning)</th>
                        <th className="py-3.5 px-4 text-center">망각곡선</th>
                        <th className="py-3.5 px-4 text-center">발음듣기</th>
                        <th className="py-3.5 px-4 text-center">훈련</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60 text-sm">
                      {filteredWords.map((word, idx) => (
                        <tr key={word.id} className="hover:bg-slate-700/40 transition-colors">
                          <td className="py-3.5 px-4 text-center text-slate-500 font-mono text-xs">{idx + 1}</td>
                          <td className="py-3.5 px-4 font-bold text-white tracking-wide">
                            {word.word}
                          </td>
                          <td className="py-3.5 px-4 text-slate-400 font-mono text-xs">{word.phonetic}</td>
                          <td className="py-3.5 px-4">
                            <span className="px-2 py-0.5 rounded text-xs font-semibold bg-indigo-950 text-indigo-300 border border-indigo-800/50">
                              {word.partOfSpeech}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-200 font-medium">{word.meaning}</td>
                          <td className="py-3.5 px-4 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                              word.isOverdue 
                                ? 'bg-rose-950 text-rose-300 border border-rose-600'
                                : 'bg-slate-900 text-amber-300 border border-slate-700'
                            }`}>
                              {word.isOverdue ? '⚠️ 2일 누적' : `${word.repetitionStage}단계`}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <button
                              onClick={() => speakWord(word.word)}
                              className="p-1.5 rounded-lg bg-slate-700 hover:bg-indigo-600 text-slate-200 hover:text-white transition-all"
                              title="발음 듣기"
                            >
                              🔊
                            </button>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <button
                              onClick={() => startTrainingSession([word])}
                              className="px-2.5 py-1 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-bold transition-all shadow"
                            >
                              훈련
                            </button>
                          </td>
                        </tr>
                      ))}
                      {filteredWords.length === 0 && (
                        <tr>
                          <td colSpan="8" className="py-12 text-center text-slate-400">
                            검색 결과에 해당하는 단어가 없습니다.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ================================================================== */}
        {/* 2. <훈련 (Training)> 화면 모드 (총 24개 세부 버전)                  */}
        {/* ================================================================== */}
        {mainTab === 'training' && (
          <div className="space-y-6">
            
            {/* ---------------- 24개 훈련 모드 제어 대시보드 ---------------- */}
            <div className="bg-slate-800/90 border border-slate-700/80 rounded-3xl p-5 shadow-xl backdrop-blur-sm space-y-4">
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-700/70 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🎛️</span>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                      <span>훈련 옵션 컨트롤러</span>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-gradient-to-r from-indigo-500 to-pink-500 text-white font-black">
                        총 24개 버전 지원
                      </span>
                    </h2>
                    <p className="text-xs text-slate-400">
                      [훈련 3종] × [언어방향 2종] × [보기방식 2종] × [카운트다운 2종]을 자유롭게 조합하세요.
                    </p>
                  </div>
                </div>

                {/* 현재 훈련 대상 단어 수 정보 */}
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-300 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-700">
                    훈련 단어: <strong className="text-indigo-400 font-bold">{activeSessionWords.length}개</strong>
                  </span>
                  <button
                    onClick={() => startTrainingSession(words)}
                    className="px-3 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-slate-200 transition-all"
                  >
                    전체 단어로 훈련
                  </button>
                </div>
              </div>

              {/* 4가지 옵션 토글 바 */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                
                {/* 1. 훈련 방식 (3종: 플래시카드 / 4지선다 / 스펠링) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-indigo-300 flex items-center gap-1">
                    <span>1. 훈련 방식</span>
                  </label>
                  <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    <button
                      id="opt-type-flashcard"
                      onClick={() => setTrainingType('flashcard')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        trainingType === 'flashcard' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      플래시카드
                    </button>
                    <button
                      id="opt-type-quiz"
                      onClick={() => setTrainingType('quiz')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        trainingType === 'quiz' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      4지선다
                    </button>
                    <button
                      id="opt-type-spelling"
                      onClick={() => setTrainingType('spelling')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        trainingType === 'spelling' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      스펠링
                    </button>
                  </div>
                </div>

                {/* 2. 언어 방향 (2종: 한->영 / 영->한) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-purple-300 flex items-center gap-1">
                    <span>2. 언어 방향</span>
                  </label>
                  <div className="grid grid-cols-2 gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    <button
                      id="opt-dir-enko"
                      onClick={() => setDirection('en-to-ko')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        direction === 'en-to-ko' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      영 ➔ 한
                    </button>
                    <button
                      id="opt-dir-koen"
                      onClick={() => setDirection('ko-to-en')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        direction === 'ko-to-en' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      한 ➔ 영
                    </button>
                  </div>
                </div>

                {/* 3. 보기 방식 (2종: 하나씩 보기 / 나열로 보기) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-pink-300 flex items-center gap-1">
                    <span>3. 보기 방식</span>
                  </label>
                  <div className="grid grid-cols-2 gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    <button
                      id="opt-view-single"
                      onClick={() => setViewType('single')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        viewType === 'single' ? 'bg-pink-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      하나씩 보기
                    </button>
                    <button
                      id="opt-view-list"
                      onClick={() => setViewType('list')}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        viewType === 'list' ? 'bg-pink-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      나열로 보기
                    </button>
                  </div>
                </div>

                {/* 4. 카운트다운 타이머 (2종: ON / OFF) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-amber-300 flex items-center gap-1">
                    <span>4. 카운트다운 타이머</span>
                  </label>
                  <div className="grid grid-cols-2 gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    <button
                      id="opt-countdown-off"
                      onClick={() => setUseCountdown(false)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        !useCountdown ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      타이머 꺼짐
                    </button>
                    <button
                      id="opt-countdown-on"
                      onClick={() => { setUseCountdown(true); setTimeLeft(10); }}
                      className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                        useCountdown ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      타이머 (10초)
                    </button>
                  </div>
                </div>

              </div>

            </div>

            {/* ---------------- 훈련 완료 결과 화면 ---------------- */}
            {isSessionFinished ? (
              <div className="max-w-2xl mx-auto bg-slate-800/90 border border-slate-700 rounded-3xl p-8 shadow-2xl text-center space-y-6">
                <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-4xl shadow-lg shadow-teal-500/30">
                  🎉
                </div>
                
                <div>
                  <h3 className="text-2xl font-black text-white">훈련을 완료했습니다!</h3>
                  <p className="text-sm text-slate-400 mt-1">
                    망각곡선 복습 주기가 성공적으로 갱신되었습니다.
                  </p>
                </div>

                {/* 결과 요약 통계 */}
                <div className="grid grid-cols-3 gap-4 bg-slate-900/80 p-4 rounded-2xl border border-slate-700/60">
                  <div>
                    <span className="text-xs text-slate-400 block">전체 단어</span>
                    <strong className="text-2xl font-bold text-white">{sessionResults.length}</strong>
                  </div>
                  <div>
                    <span className="text-xs text-emerald-400 block">맞힌 단어</span>
                    <strong className="text-2xl font-bold text-emerald-400">
                      {sessionResults.filter(r => r.isSuccess).length}
                    </strong>
                  </div>
                  <div>
                    <span className="text-xs text-rose-400 block">정답률</span>
                    <strong className="text-2xl font-bold text-indigo-400">
                      {sessionResults.length > 0 
                        ? Math.round((sessionResults.filter(r => r.isSuccess).length / sessionResults.length) * 100)
                        : 0}%
                    </strong>
                  </div>
                </div>

                {/* 상세 결과 리스트 */}
                <div className="max-h-60 overflow-y-auto divide-y divide-slate-700/50 border border-slate-700/60 rounded-2xl bg-slate-900/50 p-2 text-left text-sm">
                  {sessionResults.map((res, i) => (
                    <div key={i} className="py-2.5 px-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={res.isSuccess ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                          {res.isSuccess ? '✓' : '✗'}
                        </span>
                        <span className="font-bold text-white">{res.word.word}</span>
                        <span className="text-slate-400 text-xs">({res.word.meaning})</span>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded ${res.isSuccess ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                        {res.isSuccess ? '정답 (복습 차수 UP)' : '오답 (내일 재복습)'}
                      </span>
                    </div>
                  ))}
                </div>

                {/* 다시 시작 버튼 */}
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={() => startTrainingSession(activeSessionWords, isReviewSession)}
                    className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold transition-all shadow-lg shadow-indigo-600/30"
                  >
                    이 세션 다시 훈련하기
                  </button>
                  <button
                    onClick={() => setMainTab('study')}
                    className="px-6 py-3 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-bold transition-all"
                  >
                    학습 단어장으로 이동
                  </button>
                </div>

              </div>
            ) : (
              
              /* ---------------- 훈련 진행 중 메인 영역 ---------------- */
              <div>
                
                {/* [경우 A] 단어 하나씩 보기 (Single View) */}
                {viewType === 'single' && activeSessionWords.length > 0 && (
                  <div className="max-w-2xl mx-auto space-y-4">
                    
                    {/* 상단 진행률 바 & 타이머 */}
                    <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-1">
                      <span>문제 {currentQuestionIndex + 1} / {activeSessionWords.length}</span>
                      {useCountdown && (
                        <span className={`font-mono text-sm font-bold flex items-center gap-1 ${
                          timeLeft <= 3 ? 'text-rose-400 animate-bounce' : 'text-amber-300'
                        }`}>
                          ⏱️ {timeLeft}초 남음
                        </span>
                      )}
                    </div>

                    {/* 카운트다운 게이지 바 */}
                    {useCountdown && (
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden border border-slate-700/60">
                        <div
                          className={`h-full transition-all duration-1000 ${
                            timeLeft <= 3 ? 'bg-rose-500' : 'bg-gradient-to-r from-amber-400 to-orange-500'
                          }`}
                          style={{ width: `${(timeLeft / 10) * 100}%` }}
                        ></div>
                      </div>
                    )}

                    {(() => {
                      const currentWord = activeSessionWords[currentQuestionIndex];
                      if (!currentWord) return null;

                      // 1. 플래시 카드 모드
                      if (trainingType === 'flashcard') {
                        return (
                          <div className="space-y-6">
                            {/* 카드 인터랙션 본체 (클릭 시 플립) */}
                            <div
                              id="flashcard-interactive-card"
                              onClick={() => setIsFlipped(prev => !prev)}
                              className="relative h-80 w-full rounded-3xl bg-slate-800 border-2 border-slate-700 hover:border-indigo-500 shadow-2xl cursor-pointer transition-all duration-500 flex flex-col items-center justify-center p-8 text-center select-none group"
                            >
                              <span className="absolute top-4 right-4 text-xs font-bold text-slate-400 bg-slate-900/80 px-2.5 py-1 rounded-full border border-slate-700">
                                🔄 카드를 클릭하여 뒤집기
                              </span>

                              {!isFlipped ? (
                                /* 앞면 */
                                <div className="space-y-4 animate-fadeIn">
                                  <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">
                                    {direction === 'en-to-ko' ? '영어 단어' : '한국어 뜻'}
                                  </span>
                                  <h3 className="text-4xl sm:text-5xl font-black text-white">
                                    {direction === 'en-to-ko' ? currentWord.word : currentWord.meaning}
                                  </h3>
                                  {direction === 'en-to-ko' && (
                                    <p className="text-sm font-mono text-indigo-300">{currentWord.phonetic}</p>
                                  )}
                                  <p className="text-xs text-slate-400 mt-2">
                                    뜻을 머릿속으로 떠올린 뒤 카드를 뒤집어 확인해보세요!
                                  </p>
                                </div>
                              ) : (
                                /* 뒷면 */
                                <div className="space-y-4 animate-fadeIn">
                                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
                                    {direction === 'en-to-ko' ? '한국어 뜻' : '영어 단어'}
                                  </span>
                                  <h3 className="text-3xl sm:text-4xl font-extrabold text-emerald-300">
                                    {direction === 'en-to-ko' ? currentWord.meaning : currentWord.word}
                                  </h3>
                                  {direction === 'ko-to-en' && (
                                    <p className="text-sm font-mono text-indigo-300">{currentWord.phonetic}</p>
                                  )}
                                  <p className="text-sm text-slate-300 italic max-w-md">
                                    "{currentWord.exampleSentence}"
                                  </p>
                                </div>
                              )}

                              {/* 발음 버튼 */}
                              <button
                                onClick={(e) => { e.stopPropagation(); speakWord(currentWord.word); }}
                                className="absolute bottom-4 left-4 p-2.5 rounded-xl bg-slate-900/80 hover:bg-indigo-600 text-white text-sm transition-all"
                                title="발음 듣기"
                              >
                                🔊 발음 듣기
                              </button>
                            </div>

                            {/* 알고 있음 / 모름 버튼 */}
                            <div className="grid grid-cols-2 gap-4">
                              <button
                                id="btn-flashcard-wrong"
                                onClick={() => handleFlashcardResult(false)}
                                className="py-4 rounded-2xl bg-rose-950/60 hover:bg-rose-900 border border-rose-700/60 text-rose-200 font-bold text-base transition-all active:scale-95 flex items-center justify-center gap-2"
                              >
                                <span>❌</span>
                                <span>모름 (복습 필요)</span>
                              </button>

                              <button
                                id="btn-flashcard-correct"
                                onClick={() => handleFlashcardResult(true)}
                                className="py-4 rounded-2xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-200 font-bold text-base transition-all active:scale-95 flex items-center justify-center gap-2"
                              >
                                <span>⭕</span>
                                <span>알고 있음 (정답)</span>
                              </button>
                            </div>
                          </div>
                        );
                      }

                      // 2. 4지선다 퀴즈 모드
                      if (trainingType === 'quiz') {
                        const questionPrompt = direction === 'en-to-ko' ? currentWord.word : currentWord.meaning;
                        return (
                          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                            
                            {/* 문제 제시부 */}
                            <div className="text-center space-y-2">
                              <span className="text-xs font-bold text-indigo-400 tracking-wider uppercase">
                                {direction === 'en-to-ko' ? '다음 단어의 올바른 뜻을 고르세요' : '다음 뜻에 맞는 영어 단어를 고르세요'}
                              </span>
                              <div className="flex items-center justify-center gap-3">
                                <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
                                  {questionPrompt}
                                </h3>
                                {direction === 'en-to-ko' && (
                                  <button
                                    onClick={() => speakWord(currentWord.word)}
                                    className="p-2 rounded-lg bg-slate-700 hover:bg-indigo-600 text-white text-xs transition-all"
                                  >
                                    🔊
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* 4지선다 보기 버튼들 */}
                            <div className="grid grid-cols-1 gap-3">
                              {currentQuizOptions.map((option, idx) => {
                                const correctAnswer = direction === 'en-to-ko' ? currentWord.meaning : currentWord.word;
                                const isSelected = quizSelectedOption === option;
                                const isThisCorrect = option.trim() === correctAnswer.trim();

                                let btnStyle = "bg-slate-900/80 border-slate-700 hover:bg-slate-700 hover:border-indigo-500 text-slate-100";
                                if (quizFeedback !== null) {
                                  if (isThisCorrect) {
                                    btnStyle = "bg-emerald-900 border-emerald-500 text-white font-bold ring-2 ring-emerald-400 animate-pulse";
                                  } else if (isSelected && !isThisCorrect) {
                                    btnStyle = "bg-rose-900 border-rose-500 text-white font-bold";
                                  }
                                }

                                return (
                                  <button
                                    key={idx}
                                    onClick={() => handleQuizSelect(option)}
                                    disabled={quizFeedback !== null}
                                    className={`w-full py-4 px-5 rounded-2xl border text-left text-base sm:text-lg font-medium transition-all active:scale-[0.99] flex items-center justify-between ${btnStyle}`}
                                  >
                                    <div className="flex items-center gap-3">
                                      <span className="w-7 h-7 rounded-xl bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-400">
                                        {idx + 1}
                                      </span>
                                      <span>{option}</span>
                                    </div>
                                    {quizFeedback !== null && isThisCorrect && (
                                      <span className="text-emerald-300 font-bold text-sm">✓ 정답</span>
                                    )}
                                  </button>
                                );
                              })}
                            </div>

                          </div>
                        );
                      }

                      // 3. 스펠링 타이핑 훈련 모드
                      if (trainingType === 'spelling') {
                        const targetHint = direction === 'ko-to-en' ? currentWord.word : currentWord.meaning;
                        return (
                          <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                            
                            {/* 문제 제시부 */}
                            <div className="text-center space-y-2">
                              <span className="text-xs font-bold text-pink-400 tracking-wider uppercase">
                                {direction === 'ko-to-en' ? '뜻을 보고 영어 스펠링을 입력하세요' : '단어를 보고 뜻을 입력하세요'}
                              </span>
                              <h3 className="text-3xl sm:text-4xl font-black text-white">
                                {direction === 'ko-to-en' ? currentWord.meaning : currentWord.word}
                              </h3>
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  onClick={() => speakWord(currentWord.word)}
                                  className="text-xs text-indigo-300 hover:text-indigo-200 flex items-center gap-1 bg-slate-900/80 px-2.5 py-1 rounded-lg border border-slate-700"
                                >
                                  <span>🔊 발음 힌트 듣기</span>
                                </button>
                                <span className="text-xs text-slate-400 font-mono">
                                  글자 수: {targetHint.length}자
                                </span>
                              </div>
                            </div>

                            {/* 스펠링 입력 폼 */}
                            <form onSubmit={handleSpellingSubmit} className="space-y-4">
                              <div className="relative">
                                <input
                                  type="text"
                                  id="spelling-input-field"
                                  autoFocus
                                  value={spellingInput}
                                  onChange={(e) => setSpellingInput(e.target.value)}
                                  placeholder={direction === 'ko-to-en' ? "영단어 철자 입력..." : "한글 뜻 입력..."}
                                  disabled={spellingFeedback !== null}
                                  className={`w-full py-4 px-6 rounded-2xl bg-slate-900 border-2 text-xl font-bold tracking-wide text-white placeholder-slate-500 focus:outline-none transition-all ${
                                    spellingFeedback === 'correct'
                                      ? 'border-emerald-500 bg-emerald-950/40 text-emerald-200'
                                      : spellingFeedback === 'wrong'
                                      ? 'border-rose-500 bg-rose-950/40 text-rose-200'
                                      : 'border-slate-700 focus:border-indigo-500'
                                  }`}
                                />
                                {spellingFeedback === 'correct' && (
                                  <span className="absolute right-4 top-4 text-emerald-400 font-bold text-lg">
                                    ✓ 정답!
                                  </span>
                                )}
                              </div>

                              {/* 오답 시 정답 철자 힌트 표시 */}
                              {spellingFeedback === 'wrong' && (
                                <div className="p-3 bg-rose-950/50 border border-rose-800 rounded-xl text-center">
                                  <span className="text-xs text-rose-300 block">아쉽네요! 올바른 철자:</span>
                                  <strong className="text-base text-rose-200 font-mono tracking-widest">{targetHint}</strong>
                                </div>
                              )}

                              <button
                                type="submit"
                                id="btn-spelling-submit"
                                disabled={spellingFeedback !== null || !spellingInput.trim()}
                                className="w-full py-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-lg shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.99]"
                              >
                                정답 제출 (Enter)
                              </button>
                            </form>

                          </div>
                        );
                      }

                      return null;
                    })()}

                  </div>
                )}

                {/* [경우 B] 단어 나열로 보기 (List View) */}
                {viewType === 'list' && (
                  <div className="bg-slate-800/90 border border-slate-700 rounded-3xl p-6 shadow-xl space-y-6">
                    <div className="flex items-center justify-between border-b border-slate-700 pb-3">
                      <div>
                        <h3 className="text-lg font-bold text-white">나열형 훈련 시험지</h3>
                        <p className="text-xs text-slate-400">모든 문제에 답을 입력한 후 하단의 '일괄 채점' 버튼을 누르세요.</p>
                      </div>
                      <span className="text-xs bg-slate-900 px-3 py-1 rounded-full text-indigo-300 font-bold border border-slate-700">
                        {activeSessionWords.length}문항
                      </span>
                    </div>

                    <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 divide-y divide-slate-700/50">
                      {activeSessionWords.map((word, idx) => {
                        const prompt = direction === 'en-to-ko' ? word.word : word.meaning;
                        const feedback = listFeedbacks[word.id];

                        return (
                          <div key={word.id} className="pt-3 pb-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div className="flex items-center gap-3 sm:w-1/3">
                              <span className="w-6 h-6 rounded-md bg-slate-700 flex items-center justify-center text-xs font-bold text-slate-300">
                                {idx + 1}
                              </span>
                              <div>
                                <span className="font-bold text-white text-base">{prompt}</span>
                                {direction === 'en-to-ko' && (
                                  <span className="text-xs text-slate-400 ml-2 font-mono">{word.phonetic}</span>
                                )}
                              </div>
                            </div>

                            <div className="flex-1">
                              <input
                                type="text"
                                value={listAnswers[word.id] || ""}
                                onChange={(e) => setListAnswers({ ...listAnswers, [word.id]: e.target.value })}
                                placeholder={direction === 'en-to-ko' ? "뜻 입력..." : "영어 단어 입력..."}
                                className={`w-full px-4 py-2 rounded-xl bg-slate-900 border text-sm text-white focus:outline-none ${
                                  feedback === 'correct' 
                                    ? 'border-emerald-500 bg-emerald-950/40' 
                                    : feedback === 'wrong' 
                                    ? 'border-rose-500 bg-rose-950/40' 
                                    : 'border-slate-700 focus:border-indigo-500'
                                }`}
                              />
                            </div>

                            {/* 발음 버튼 */}
                            <button
                              onClick={() => speakWord(word.word)}
                              className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs"
                              title="발음 듣기"
                            >
                              🔊
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    <div className="pt-4 border-t border-slate-700 text-center">
                      <button
                        onClick={handleGradeListAnswers}
                        className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold shadow-lg shadow-indigo-500/30 hover:brightness-110 active:scale-95 transition-all text-base"
                      >
                        시험지 일괄 채점하기
                      </button>
                    </div>

                  </div>
                )}

              </div>
            )}

          </div>
        )}

      </main>

      {/* ================================================================== */}
      {/* [모달 1] 망각곡선 주기별 자동 복습 팝업                             */}
      {/* ================================================================== */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-6 animate-scaleUp">
            
            {/* 팝업 헤더 */}
            <div className="flex items-center justify-between border-b border-slate-700 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🧠</span>
                <div>
                  <h3 className="text-lg font-bold text-white">망각곡선 스마트 복습 시스템</h3>
                  <p className="text-xs text-slate-400">주기별 단어를 선택한 분량만큼 추출하여 복습합니다.</p>
                </div>
              </div>
              <button
                onClick={() => setShowReviewModal(false)}
                className="text-slate-400 hover:text-white text-xl p-1"
              >
                ✕
              </button>
            </div>

            {/* 현재 복습 대기 상태 */}
            <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-700/80 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-300">오늘 복습 대상 단어:</span>
                <strong className="text-amber-400 font-bold">{dueWords.length}개</strong>
              </div>
              
              {overdueWords.length > 0 && (
                <div className="flex items-center justify-between text-sm text-rose-400 font-semibold bg-rose-950/40 p-2 rounded-xl border border-rose-800/40">
                  <span>⚠️ 2일 이상 미복습 누적:</span>
                  <strong className="text-rose-300">{overdueWords.length}개 (우선 복습 필요!)</strong>
                </div>
              )}
            </div>

            {/* 1. 복습 분량 선택 (100% / 70% / 50% / 30%) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-indigo-300 block">
                복습 분량 선택 (랜덤 추출 퍼센티지)
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: '전체 (100%)', val: 1.0 },
                  { label: '70% 단어', val: 0.7 },
                  { label: '50% 단어', val: 0.5 },
                  { label: '30% 단어', val: 0.3 }
                ].map(item => (
                  <button
                    key={item.val}
                    onClick={() => setReviewRatio(item.val)}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all border ${
                      reviewRatio === item.val
                        ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/30'
                        : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-400">
                선택한 비율에 따라 대상 단어 중 무작위로 문제를 선정합니다.
              </p>
            </div>

            {/* 2. 단어장 3개 기능 중 하나를 선택해 복습 시작 */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-amber-300 block">
                복습을 진행할 훈련 방식을 선택하세요:
              </label>
              <div className="grid grid-cols-1 gap-2.5">
                <button
                  id="btn-review-flashcard"
                  onClick={() => handleStartReviewWithRatio('flashcard')}
                  className="p-3.5 rounded-2xl bg-slate-900 hover:bg-indigo-950/80 border border-slate-700 hover:border-indigo-500 text-left transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🎴</span>
                    <div>
                      <span className="font-bold text-white text-sm group-hover:text-indigo-300">
                        1. 플래시 카드로 복습하기
                      </span>
                      <p className="text-xs text-slate-400">카드를 넘기며 기억 여부를 체크합니다.</p>
                    </div>
                  </div>
                  <span className="text-indigo-400 text-sm">시작 ➔</span>
                </button>

                <button
                  id="btn-review-quiz"
                  onClick={() => handleStartReviewWithRatio('quiz')}
                  className="p-3.5 rounded-2xl bg-slate-900 hover:bg-indigo-950/80 border border-slate-700 hover:border-indigo-500 text-left transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🎯</span>
                    <div>
                      <span className="font-bold text-white text-sm group-hover:text-indigo-300">
                        2. 4지선다 퀴즈로 복습하기
                      </span>
                      <p className="text-xs text-slate-400">객관식 4개 보기 중 올바른 뜻을 맞힙니다.</p>
                    </div>
                  </div>
                  <span className="text-indigo-400 text-sm">시작 ➔</span>
                </button>

                <button
                  id="btn-review-spelling"
                  onClick={() => handleStartReviewWithRatio('spelling')}
                  className="p-3.5 rounded-2xl bg-slate-900 hover:bg-indigo-950/80 border border-slate-700 hover:border-indigo-500 text-left transition-all flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">✍️</span>
                    <div>
                      <span className="font-bold text-white text-sm group-hover:text-indigo-300">
                        3. 스펠링 훈련으로 복습하기
                      </span>
                      <p className="text-xs text-slate-400">철자를 키보드로 직접 쓰며 완벽하게 외웁니다.</p>
                    </div>
                  </div>
                  <span className="text-indigo-400 text-sm">시작 ➔</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ================================================================== */}
      {/* [모달 2] 새 단어 추가 팝업                                          */}
      {/* ================================================================== */}
      {showAddWordModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-scaleUp">
            
            <div className="flex items-center justify-between border-b border-slate-700 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>➕</span>
                <span>나만의 단어 추가하기</span>
              </h3>
              <button
                onClick={() => setShowAddWordModal(false)}
                className="text-slate-400 hover:text-white text-xl p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddWordSubmit} className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">영어 단어 *</label>
                  <input
                    type="text"
                    required
                    placeholder="예: explore"
                    value={newWordData.word}
                    onChange={(e) => setNewWordData({ ...newWordData, word: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">한글 뜻 *</label>
                  <input
                    type="text"
                    required
                    placeholder="예: 탐험하다, 탐구하다"
                    value={newWordData.meaning}
                    onChange={(e) => setNewWordData({ ...newWordData, meaning: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">발음기호</label>
                  <input
                    type="text"
                    placeholder="예: /ɪkˈsplɔːr/"
                    value={newWordData.phonetic}
                    onChange={(e) => setNewWordData({ ...newWordData, phonetic: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">품사</label>
                  <select
                    value={newWordData.partOfSpeech}
                    onChange={(e) => setNewWordData({ ...newWordData, partOfSpeech: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="동사">동사</option>
                    <option value="명사">명사</option>
                    <option value="형용사">형용사</option>
                    <option value="부사">부사</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">예문 (영어)</label>
                <input
                  type="text"
                  placeholder="예: We should explore new possibilities."
                  value={newWordData.exampleSentence}
                  onChange={(e) => setNewWordData({ ...newWordData, exampleSentence: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">예문 해석 (우리말)</label>
                <input
                  type="text"
                  placeholder="예: 우리는 새로운 가능성을 탐구해야 합니다."
                  value={newWordData.exampleTranslation}
                  onChange={(e) => setNewWordData({ ...newWordData, exampleTranslation: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">유의어 (쉼표 구분)</label>
                  <input
                    type="text"
                    placeholder="investigate, search"
                    value={newWordData.synonyms}
                    onChange={(e) => setNewWordData({ ...newWordData, synonyms: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">반의어 (쉼표 구분)</label>
                  <input
                    type="text"
                    placeholder="ignore, overlook"
                    value={newWordData.antonyms}
                    onChange={(e) => setNewWordData({ ...newWordData, antonyms: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddWordModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-300 font-semibold"
                >
                  취소
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-md shadow-indigo-600/30"
                >
                  단어 저장하기
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* ----------------- 푸터 ----------------- */}
      <footer className="border-t border-slate-800 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <p>© 2026 보카하이 (vocahigh) - 에빙하우스 망각곡선 주기 자동 복습 & 24개 맞춤 훈련 시스템</p>
      </footer>

    </div>
  );
}
